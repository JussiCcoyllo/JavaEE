package be.intecbrussel;

public class AutoApp {
    public static void main(String[] args) {

       Car car = new Car();

        Car car1 = new Car("violet", 60,120);
        Car car2 = new Car("green",70, 150);
        Car car3 = new Car("yellow", 160, 200);


        System.out.println("Car 1 is : " + car1.getColor());
        System.out.println("Car 2 is : " + car2.getColor() + ", its speed is : " + car2.getMaxSpeed());
        System.out.println("Car 3 is : " + car3.getColor() + ", its speed is : " + car3.getMaxSpeed() + ", its horse power is : " + car3.getHorsePower());

        car.speedEnter();

        car.speedUp();
//        car.paint();

        car.repair();

        car.lightsCar();

    }
}
