package be.intecbrussel;
import com.sun.security.jgss.GSSUtil;

import java.util.Random;
import java.util.Scanner;
public class Car {

    Scanner myScanner = new Scanner(System.in);

    //properties
    private String color;
    private int maxSpeed = 150;
    private int horsePower;
    private String colorDefault = "white";
    int speedNow = 0;
    private int maxSpeedDefault = 120;
    private int horsePowerDefault = 150;

    //constructors

    public Car(String color, int maxSpeed, int horsePower) {

        this.color = color;
        this.maxSpeed = maxSpeed;
        this.horsePower = horsePower;
    }

    public Car() {

    }

    public String getColor() {
        return color;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public int getHorsePower() {
        return horsePower;
    }

    //methode

    public void speedUp() {
        speedNow += 5;
    }

    public void slowDown() {
        speedNow -= 5;
    }

    public void speedEnter() {
        System.out.println("Enter your current speed : ");
        int speedNow = myScanner.nextInt();

        if (speedNow <= maxSpeed && speedNow > 0) {
            speedNow += 5;
//           speedUp();
//           slowDown();
            System.out.println(speedNow);
        } else {
            System.out.println("Speed non authorised");
        }
    }

    public void paint() {

        switch (color) {
            case "violet":
                System.out.println("Your car color is going to change to green");
            case "green":
                System.out.println("Your car color is going to change to violet");
            case "yellow":
                System.out.println("Your car color is going to change to white");
            default:
                System.out.println("don't change");

        }
    }

    public void repair() {

        int priceRepair = (int) (100 + Math.random() * 200);

        System.out.println("The repair cost is " + priceRepair);

    }

    boolean lightsOn = false;
    public void lightsCar(){
        lightsOn = !lightsOn;

        if (lightsOn == true){
            System.out.println("Your car lights are on");
        } else {
            System.out.println("Your car lights are off");
        }
    }

    @Override
    public String toString() {
        return "Car{" +
                "color='" + color + '\'' +
                ", maxSpeed=" + maxSpeed +
                ", currentSpeed=" + speedNow +
                '}';
    }
}

