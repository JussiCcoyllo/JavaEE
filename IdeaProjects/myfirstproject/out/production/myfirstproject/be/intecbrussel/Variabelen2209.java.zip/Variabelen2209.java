package be.intecbrussel;

public class Variabelen2209 {


    public static void main(String[] args){

        //1
        int number1 = 1250;
        int number2 = 24000;

        int result = number1 + number2;
        System.out.println("(+) = " + result);

        int result2 = number1 - number2;
        System.out.println("(-) = " + result2);

        int result3 = number1 * number2;
        System.out.println("(*) = " + result3);

        int result4 = number2 / number1;
        System.out.println("(/) = " + result4);

        int result5 = number2 % number1;
        System.out.println("(%) = " + result5);

        //2
        int num1 = -5 + 8 * 6;
        System.out.println("a. " + num1);

        int num2 = (55 + 9) % 9;
        System.out.println("b. " + num2);

        int num3 = 20 + -3*5 / 8;
        System.out.println("c. " + num3);

        int num4 = 5 + 15 / 3 * 2 - 8 % 3;
        System.out.println("d. " + num4);

        //3
        double lengte = 25.5;
        double breedte = 12.5;

        double rechthoek = lengte * breedte;
        System.out.println("Oppervlakte van een rechthook = " + rechthoek);

        //4
        int first = 25;
        int second = 39;

        System.out.println("first == second: " + (first == second));

        //5

        System.out.println("   J    a   v     v  a");
        System.out.println("   J   a a   v   v  a  a");
        System.out.println("J  J  aaaaa   V V  aaaaaa");
        System.out.println(" JJ  a     a   V  a      a");

        }

    }


